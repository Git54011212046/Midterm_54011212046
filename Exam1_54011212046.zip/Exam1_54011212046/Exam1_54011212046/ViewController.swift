//
//  ViewController.swift
//  Exam1_54011212046
//
//  Created by iStudents on 3/13/15.
//  Copyright (c) 2015 iStudents. All rights reserved.
//
//jkjkjk
import UIKit

class ViewController: UIViewController, UITableViewDelegate {

    @IBOutlet weak var inputFinal: UITextField!
    @IBOutlet weak var inputMidterm: UITextField!
    @IBOutlet weak var inputBonus: UITextField!
    @IBOutlet weak var inputSubject: UITextField!


   
    
   
    @IBOutlet weak var labelGrade: UILabel!
    
    @IBOutlet weak var labelScore: UILabel!
    
    
    @IBOutlet weak var labelSubject: UILabel!
    
    @IBOutlet weak var final1: UILabel!

    @IBOutlet weak var final2: UILabel!
    @IBOutlet weak var final3: UILabel!
    var subject = ""
    var midterm = 0.0
    var final = 0.0
    var bonus = 0.0
    
    //var grade = ""

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
     
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    @IBAction func calculateGrade(sender: AnyObject) {
        getData()
        var sumpoint = 0.0
        sumpoint = midterm + final + bonus
        var getGrade = calculate(sumpoint)
        /*labelGrade.text = "Subject: \(subject) Point: \(sumpoint) Grade: \(getGrade)"*/
        labelSubject.text = "Subject: \(inputSubject.text)"
        labelScore.text = "Score  :  \(sumpoint)"
        labelGrade.text = "Grade  :  \(getGrade)"
        gradeMore()
        
        
        
    }
    func gradeMore () {
        var point = (point1: 0.0, point2: 0.0, point3: 0.0)
        point.point1 = midterm + bonus + (final * (100 - 5) / 100)
        point.point2 = midterm + bonus + (final * (100 - 10) / 100)
        point.point3 = midterm + bonus + (final * (100 + 15) / 100)
        var g1 = calculate(point.point1)
        var g2 = calculate(point.point2)
        var g3 = calculate(point.point3)
        
        final1.text = "Final < 5%    :\(point.point1) Grade: \(g1)"
        final2.text = "Final < 10%  :\(point.point1) Grade: \(g2)"
        final3.text = "Final > 15%  :\(point.point1) Grade: \(g3)"
        
    }
    func getData () {
        subject = inputSubject.text
        midterm = Double((inputMidterm.text as NSString).doubleValue)
        final = Double((inputFinal.text as NSString).doubleValue)
        bonus = Double((inputBonus.text as NSString).doubleValue)
        
    }
    func calculate (point: Double) -> String{
        var grade = ""
        if point >= 80 {
            grade = "A"
        } else if point >= 74 {
            grade = "B+"
        } else if point >= 68 {
            grade = "B"
        } else if point >= 62 {
            grade = "C+"
        } else if point >= 56 {
            grade = "C"
        } else if point >= 50 {
            grade = "D+"
        } else if point >= 44 {
            grade = "D"
        } else {
            grade = "F"
        }
        return grade
    }

}

